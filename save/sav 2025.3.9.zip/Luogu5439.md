---
title: Luogu5439  【XR-2】永恒
date: 2025-03-02 04:16:10
tags: [数据结构]
mathjax: true
categories:
  - [算法竞赛, 题, 洛谷]
---

**题意** ： 给出两棵树 $T_1,T_2$ ，标号对应。

定义 $lcadep(u,v)$ 为 $T_2$ 上 $u,v$ 两点的 $\rm lca$ 的深度，也简记为 $ld(u,v)$。

定义 $T_1$ 上一条路径 $P:u\leftrightarrow v$ 的价值为 

$$
\sum_{a\in P,\,b\in P,\,a<b}ld(a,b)
$$
求 $T_1$ 所有无向路径的价值和，答案对 $998244353$ 取模。

$|T_1|,|T_2|\leq 3\times 10^5$，时限 $\texttt{10s}$。

<!-- more -->

------------

统计树上点对贡献。

考虑点分治，每次处理通过分治中心 $t$ 的所有路径的贡献。

令整颗原树以 $t$ 为根，设 $siz[u]$ 为 $u$ 点的子树大小。其求解可以借助点分治。

若 $(u,v)$ 不在同一个子树内，同时经过 $u,v$ 的路径总数即为 $siz[u]\times siz[v]$。

于是问题变成了：

$$
\sum_{u}\sum_{v}ld(u,v)siz[u]siz[v]
$$
这可以在 $T_2$ 上建立虚树，然后树形 $\rm DP$ 计算。

利用归并和 $O(1)\ \rm LCA$ 建立虚树，复杂度为 $O(n\log n+m\log m)$。
