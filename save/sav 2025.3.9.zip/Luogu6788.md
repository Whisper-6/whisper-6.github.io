---
title: Luogu6788 「EZEC-3」四月樱花
date: 2025-03-02 03:17:51
tags: [数论]
mathjax: true
categories:
  - [算法竞赛, 题, 洛谷]
---

**题意**：给出 $n$，求
$$
  \prod_{a=1}^n\prod_{b|a}\dfrac{b^{d(b)}}{\prod_{c|b}(c+1)^2}
$$

  答案对给定的大质数 $p$ 取模，$n\leq 2.5\times 10^9$。

<!-- more -->

-----

分子分母分别推导，为了简便，考虑先取 $\ln$ 再取 $\exp$。
$$
\begin{aligned}
\ln \prod_{a=1}^n\prod_{b|a}b^{d(b)}&=\sum_{a=1}^n\sum_{b|a}d(b)\ln b\\
&=\sum_{a=1}^n\sum_{b|a}\sum_{c|b}\ln b\\
&=\sum_{c=1}^n\sum_{c|b,1\leq b\leq n}\ln b\sum_{b|a,1\leq a\leq n}1\\
&=\sum_{c=1}^n\sum_{i=1}^{\lfloor n/c\rfloor}(\ln c+\ln i)\lfloor n/ci\rfloor\\
&=2\sum_{c=1}^n\ln c\sum_{i=1}^{\lfloor n/c\rfloor}\lfloor n/ci\rfloor\\
\end{aligned}
$$

最后一步用到了 $i$ 和 $c$ 的对称性。

$$
\begin{aligned}
\ln \prod_{a=1}^n\prod_{b|a}\prod_{c|b}(c+1)^2&=\sum_{a=1}^n\sum_{b|a}\sum_{c|b}2\ln(c+1)\\
&=2\sum_{c=1}^n\ln(c+1)\sum_{i=1}^{\lfloor n/c\rfloor}\lfloor n/ci\rfloor\\
\end{aligned}
$$

记 $S(n)=\sum_{i=1}^n\lfloor n/i\rfloor$，将两者相减，并取 $\exp$
$$
\begin{aligned}
\prod_{a=1}^n\prod_{b|a}\dfrac{b^{d(b)}}{\prod_{c|b}(c+1)^2}&=\exp2\left(\sum_{c=1}^n\big(\ln c-\ln(c+1)\big)S\big(\lfloor n/c\rfloor\big)\right)\\
&=\left(\prod_{c=1}^n\left(\dfrac{c}{c+1}\right)^{S(\lfloor n/c\rfloor)}\right)^2
\end{aligned}
$$

采用杜教筛技巧求所需的 $S$，然后整除分块（一段的连乘积 $\prod_{c=l}^r\big(\frac{c^2}{(c+1)^2}\big)^{S}=\big(\frac{l^2}{(r+1)^2}\big)^{S}$ ），复杂度 $O(n^{2/3}+\sqrt{n}\log p)$。
