---
title: Luogu5438 【XR-2】记忆
date: 2025-03-02 04:13:37
tags: [数论]
mathjax: true
categories:
  - [算法竞赛, 题, 洛谷]
---

**题意**：对于一个序列 $P$，定义其权值为满足 $P_iP_{i+1}$ 为平方数的 $i$ 的个数。

现在 $P$ 中含有数 $[l,r]∩Z$，求可能的最大权值。

$l,r\leq 10^{14}$，时限 $\texttt{1.2s}$。

<!-- more -->

------------

两个数相乘为完全平方数的充要条件：奇次数质因子集合相同。

那么，我们按照奇次数质因子集合给数分类，将同类的数放在一起，则权值为 $r-l-$ 等价类个数。显然这是上界了。

现在的目标就是求等价类个数。

-----

枚举奇次数质因子的积，考虑有多少个偶次数质因子也就是平方数能配合。

$$
{\rm Ans}=\sum\limits_{i=1}^r\mu^2(i)\bigg[\Big\lfloor\sqrt{r/i}\Big\rfloor-\Big\lfloor\sqrt{(l-1)/i}\Big\rfloor>0\bigg]
$$
对后者整除分块，会分成 $O(n^{1/3})$ 块。对于每一块，需要求出 $\mu^2$ 的部分和。

众所周知
$$
\sum\limits_{i=1}^n\mu^2(i)=\sum\limits_{i=1}^{\sqrt{n}}\mu(i)\lfloor n/i^2\rfloor
$$
这也能 $O(n^{1/3})$ 整除分块计算。

-----

复杂度分析：

枚举 $\sqrt{n/i}=k$ ，则有 $i=n/k^2$。

当 $k\leq n^{1/3}$ 时，复杂度为 $O\left(\sum\limits_{k=1}^{n^{1/3}}(n/k^2)^{1/3}\right)=O(n^{4/9})$。

当 $k\geq n^{1/3}$ 时，则有 $i\leq n^{1/3}$，复杂度为 $O\left(\sum\limits_{i=1}^{n^{1/3}}i^{1/3}\right)=O(n^{4/9})$

线性筛 $\mu$ 的复杂度为 $O(\sqrt{n})$。

总复杂度 $O(\sqrt{n})$。


