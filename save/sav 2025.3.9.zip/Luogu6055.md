---
title: Luogu6055 [RC-02] GCD
date: 2025-03-02 03:46:46
tags: [数论]
mathjax: true
categories:
  - [算法竞赛, 题, 洛谷]
---

**题意**：给出 $N$，求：
$$
\sum_{i=1}^N\sum_{j=1}^N\sum_{p=1}^{\lfloor\frac{N}{j}\rfloor}\sum_{q=1}^{\lfloor\frac{N}{j}\rfloor}[\gcd(i,j)=1][\gcd(p,q)=1]
$$

答案对 $998244353$ 取模，$N\leq 2\times 10^9$，时限 $\texttt{1s}$。

<!-- more -->

------------

出题人往数论求和题里面编类似组合意义的东西…… 我还是相信代数推导保平安。
$$
\begin{aligned}
&\sum\limits_{i=1}^N\sum\limits_{j=1}^N\sum\limits_{p=1}^{\lfloor N/j\rfloor}\sum\limits_{q=1}^{\lfloor N/j\rfloor}[\gcd(i,j)=1][\gcd(p,q)=1]\\
&=\sum\limits_{i=1}^N\sum\limits_{j=1}^N[\gcd(i,j)=1]\,\boxed{\sum\limits_{p=1}^{\lfloor N/j\rfloor}\sum\limits_{q=1}^{\lfloor N/j\rfloor}[\gcd(p,q)=1]}\\
&=\sum\limits_{i=1}^N\sum\limits_{j=1}^N[\gcd(i,j)=1]G(\lfloor N/j\rfloor)\\
&=\sum\limits_{i=1}^N\sum\limits_{j=1}^N\sum\limits_{d|i,d|j}\mu(d)G(\lfloor N/j\rfloor)\\
&=\sum\limits_{d=1}\mu(d)\sum\limits_{d|i}^N\sum\limits_{d|j}^NG(\lfloor N/j\rfloor)\\
&=\sum\limits_{d=1}\mu(d)\lfloor N/d\rfloor\sum\limits_{j=1}^{\lfloor N/d\rfloor}G(\lfloor N/jd\rfloor)\\
\end{aligned}
$$
其中 
$$
\begin{aligned}
G(m)&=\sum_{p=1}^m\sum_{q=1}^m[\gcd(p,q)=1]\\
&=\sum_{d=1}^m\mu(d)\lfloor n/d\rfloor^2
\end{aligned}
$$

-----

答案的前半部分已经足够简洁，只需化简
$$
\sum\limits_{j=1}^{\lfloor N/d\rfloor}G(\lfloor N/jd\rfloor)
$$
设 $F(m)=\sum_{j=1}^{m}G(\lfloor m/j\rfloor)$ ，上式为 $F(\lfloor N/d\rfloor)$。
$$
\begin{aligned}
F(m)&=\sum_{j=1}^{m}G(\lfloor m/j\rfloor)\\
&=\sum_{j=1}^{m}\sum_{d=1}^m\mu(d)\lfloor m/jd\rfloor^2\\
&=\sum_{T=1}^{m}\lfloor m/T\rfloor^2\sum_{d|T}\mu(d)&(T=jd)\\
&=\sum_{T=1}^{m}\lfloor m/T\rfloor^2[T=1]\\
&=m^2
\end{aligned}
$$
综上
$$
{\rm Ans}=\sum_{d=1}\mu(d)\lfloor N/d\rfloor^3
$$
杜教筛即可，复杂度 $O(n^{2/3})$。
