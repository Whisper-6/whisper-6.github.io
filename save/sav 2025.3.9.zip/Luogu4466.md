---
title: Luogu4466 [国家集训队] 和与积
date: 2025-03-05 15:00:25
tags: [数论]
mathjax: true
categories:
  - [算法竞赛, 题, 洛谷]
---

**题意**：给出 $n$，求
$$
\sum\limits_{a=1}^n\sum\limits_{b=a+1}^n[(a+b)|ab]
$$
$n\leq 2^{31}-1$，时限 $\texttt{1s}$。

<!-- more -->

------------

并不是经典形式,无从下手。

先观察一下 $[(a+b)|ab]$ 的充要条件。

显然 $(a,b)>1$，否则 $\gcd(a,a+b)=\gcd(b,a+b)=1$ ,那么 $\gcd(ab,a+b)=1$。

设 $d=(a,b)$，令 $a'=a/d,b'=b/d$，则
$$
(a+b)\mid ab\ \Leftrightarrow\ (a'+b')\mid a'b'd\ \Leftrightarrow\ (a'+b')|d\ \Leftrightarrow\ (a+b)|d^2
$$
总之：$[(a+b)|ab]=[(a+b)|\gcd(a,b)^2]$。

接下来可以开推了：
$$
\begin{aligned}
{\rm Ans}&=\sum_{1\leq a,b\leq n}[a<b]\big[(a+b)|\gcd(a,b)^2\big]\\
&=\sum_{d}\sum_{1\leq a,b\leq n}[a<b]\big[\gcd(a,b)=d\big]\big[(a+b)|d^2\big]\\
&=\sum_{a,b,d}[ad<bd\leq n][a\perp b][(a+b)|d]&(a\gets a/d,\,b\gets b/d)\\
&=\sum_{a,b,k}[a(a+b)k<b(a+b)k\leq n][a\perp b]&\Big(k(a+b)=d\Big)\\
&=\sum_{a,b}\left\lfloor\dfrac{n}{b(a+b)}\right\rfloor[a<b][a\perp b]\\
&=\sum_{a,b}\left\lfloor\dfrac{n}{b(a+b)}\right\rfloor[a<b]\sum_{r|a,r|b}\mu(r)\\
&=\sum_{r=1}\mu(r)\sum_{r|a,r|b}\left\lfloor\dfrac{n}{b(a+b)}\right\rfloor[a<b]\\
&=\sum_{r=1}^{\sqrt{n}}\mu(r)\sum_{a=1,b=1}^{n/r}\left\lfloor\dfrac{n}{b(a+b)r^2}\right\rfloor[a<b]\\
&=\sum_{r=1}^{\sqrt{n}}\mu(r)\sum_{b=2}^{\sqrt{n}/r}\sum_{a=1}^{b-1}\left\lfloor\dfrac{n}{b(a+b)r^2}\right\rfloor\\
&=\sum_{r=1}^{\sqrt{n}}\mu(r)\sum_{b=2}^{\sqrt{n}/r}\sum_{a=b+1}^{2b-1}\left\lfloor\dfrac{n}{abr^2}\right\rfloor
\end{aligned}
$$
然后用整除分块大力计算。

只要 $r,b$ 确定, $\sum_{a=b+1}^{2b-1}\left\lfloor\dfrac{n}{abr^2}\right\rfloor$ 可以使用整除分块在 $O(\sqrt{n/br^2})$ 的时间内算得。

对于一个确定的 $m=n/r^2$ ，复杂度是 $\sum_{b=1}^{\sqrt{m}}\sqrt{m/b}=O(m^{3/4})$。

外层对 $n/r^2$ 分块，形成 $O(n^{1/3})$ 段。

总复杂度为 $\sum_{r=1}^{n^{1/3}}(n/r^2)^{3/4}=O(n^{3/4})$。
