---
title: Luogu6562 [SBCOI2020] 归家之路
date: 2025-03-04 14:04:04
tags: [数据结构]
mathjax: true
categories:
  - [算法竞赛, 题, 洛谷]
---

**题意**：定义一种布尔类型运算 $a\otimes b$：如果在 $a$ 的**二进制**表示中，满足每一个 $a$ 是 $1$ 的位，$b$ 的对应位也是 $1$，那么  $a\otimes b$ 为 `True` , 否则为 `False`。

维护一个长度为 $2^n$，标号为 $0\dots2^n-1$ 的序列 $S$，支持如下操作。

- 给出 $a,b,k$，将所有满足 $a\otimes  c,\ c\otimes b$ 的 $S$ 加上 $k$。

- 给出 $a,b$，查询 $\sum\limits_{c}(a\otimes  c)(c\otimes b)S[c]$。

$n\leq 16$，$q\leq 2\times 10^5$，时限 $\texttt{1s}$。

<!-- more -->

------------

有趣的题目。

## 无修改

称 $\left<a,b\right>=\{c\mid a\otimes  c,\ c\otimes b\}$，我们要研究这个集合的结构。
$$
\begin{aligned}
a\otimes b
&\ \Leftrightarrow\ 
a\subseteq b\\
a\otimes  c,\ c\otimes b
&\ \Leftrightarrow\ 
a\subseteq c\subseteq b\\
&\ \Rightarrow\ (c-a)\subseteq (b-a)
\end{aligned}
$$
询问相当于：指定若干位 （$a$）为 $1$，若干位（$U-b$） 为 $0$，其余位（$b-a$）随意。

这样，可能的 $c$ 的个数就是 $O(2^{|b-a|})$。当然，$|b-a|$ 仍然有可能较大。

当 $|b-a|$（不确定的位的个数） 较大时，确定的位相应地较少。

设 $f(s_0,s_1)$ 表示钦定位集合 $s_0$ 为 $0$，位集合 $s_1$ 为 $1$ 的位置的和。

当 $s_1=\varnothing$ 时，相当于子集求和，提前 $O(2^nn)$ 预处理即可。

否则，设 $p$ 为 $s_1$ 中任意一个元素，有：

$$
f(s_1,s_0)=f(s_1-p,s_0)-f(s_1-p,s_0+p)
$$
意思是，用 $p=0/1$ 的方案减去 $p=0$ 的方案，即可得到 $p=1$ 的方案。

利用这个式子递推，复杂度为 $O(2^{|U-a|})$。

和暴力求和结合，复杂度为 $O(2^{n/2})$。似乎也可以做到 $O(2^{n/3})$。

------

## 考虑修改

接下来考虑带修的情况。对时间分块，块大小设为 $B$。

- 零散的 $B$ 个修改对询问的贡献。

  相当于我们要计算两个形如 $R=\{c\mid a\subseteq c\subseteq b\}$ 的集合的交集。
  
  假设 $R_1$ 中指定位集合 $a_1$ 为 $0$，位集合 $b_1$ 为 $1$。$R_2$ 中类似。
  
  $c$ 同时属于 $R_1,R_2$ 相当于指定 $a_1∪a_2$ 为 $0$，$b_1∪b_2$ 为 $1$。
  

每过 $B$ 个修改就重新计算一次 $S$ 以及 $S$ 的子集和。

可以用同样的递推方式将一次加法操作转化为对 $O(2^{n/2})$ 个子集的加法，或者是单点加法。

使用高维后缀和即可批量计算子集加法。

这样的复杂度是 $O\big(q(B+2^{n/2})+2^nnq/B\big)$ 取 $B=\sqrt{2^nn}$ 可得复杂度为 $O(q2^{n/2}\sqrt{n})$。

常数较小。

  
